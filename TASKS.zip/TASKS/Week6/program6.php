<!-- 6. Implement a PHP function that removes duplicate values 
        from an array without using array_unique. -->

<?php

$array = [1, 4, 2, 5, 5 , 3, 4, 5];

function duplicateValue($array) {
    $newValue = [];

    for ($i = 0; $i < count($array); $i++) {
        $element = $array[$i];
        if (!in_array($element, $newValue)) {
            $newValue[] = $element;
        }
    }

    return $newValue;
}

$newArray = duplicateValue($array);
print_r($newArray);
?>