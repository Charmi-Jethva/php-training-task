<!-- 4. Write a PHP function to reverse a given string without 
        using built-in functions like strrev. -->

<?php
$str = "Charmi";
$len = strlen($str);
for ($i= $len - 1 ; $i >= 0 ; $i--)
{
echo $str[$i];
}
?>