<!-- 10. Create a database with name week_6_database and create one table with this fields

id
first_name
last_name
email
contact_no
department
designation
gender
salary
created_at
updated_at

perform the queries on the employee table in your database and write all this into the text file -->

<!-- 1. Query to create employee (Insert) -->

INSERT INTO employee(`id`, `first_name`, `last_name`, `email`, `contact_no`, `department`, `designation`, `gender`, `salary`) VALUES ('1','Payal','Hadiyal','payal@gmail.com','1234567890','.net','Software developer','Female','30000');

INSERT INTO employee(`id`, `first_name`, `last_name`, `email`, `contact_no`, `department`, `designation`, `gender`, `salary`) VALUES ('2','Charmi','Jethva','charmi@gmail.com','1234567890','php','trainee','Female','5000');

INSERT INTO employee(`id`, `first_name`, `last_name`, `email`, `contact_no`, `department`, `designation`, `gender`, `salary`) VALUES ('3','foram','patel','foram@gmail.com','1234567890','python','trainee','Female','3000');

INSERT INTO employee(`id`, `first_name`, `last_name`, `email`, `contact_no`, `department`, `designation`, `gender`, `salary`) VALUES ('4','drashti','patel','drashti@gmail.com','1234567890','php','trainee','Female','5000');

INSERT INTO employee(`id`, `first_name`, `last_name`, `email`, `contact_no`, `department`, `designation`, `gender`, `salary`) VALUES ('5','abhisha','patel','abhisha@gmail.com','1234567890','laravel','software developer','Female','45000');


<!--2. Query to update specific employee. -->

UPDATE employee SET salary='6000' WHERE 'id' = 2;


<!--3. Retrieve all the columns for all rows in the "employees" table. -->

SELECT * FROM employee;

<!--4. Retrieve the names(first_name + last_name ex: Taral Nagar) and salaries of employees who earn more than 20,000 per year. -->

SELECT CONCAT(`first_name`,' ' ,`last_name`), `salary` FROM `employee` WHERE `salary` > 20000;

<!--5. List the names and created dates of employees in descending order of created date. -->

SELECT CONCAT(`first_name`,' ' ,`last_name`), `created_at` FROM `employee` ORDER BY `created_at` DESC;

<!-- 6. Calculate the average salary of all employees in the "employees" table. -->

SELECT AVG(salary) FROM employee;

<!--7. Retrieve the names(first_name + last_name ex: Taral Nagar) of employees based on their department (using group by)

eg. like department php then list of the employee that are worked under php department -->

SELECT GROUP_CONCAT(`first_name`, ' ', `last_name`), `department` FROM employee GROUP BY department;

<!-- 8. Delete ae that were placed more than one year ago. -->

DELETE FROM employee
WHERE DATE_ADD(created_at, INTERVAL 1 YEAR) < NOW(); 

 
<!-- 9.List the names and email addresses of customers who have salary more than 20000 and less than 45000 -->

SELECT CONCAT(`first_name`,' ' ,`last_name`),`email` FROM `employee` WHERE salary > 20000 && 45000;

<!--10. 11 July 2023 Mon -->

SELECT DATE_FORMAT(NOW(), '%d %M %Y');

SELECT DATE_FORMAT('2023-07-11', '%d %M %Y');