<!-- 5. Create a PHP function to calculate the average of an array of 
        numbers without using the array_sum or count built-in. -->

<?php

$numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

function calculate($numbers) {
    $sum = 0;
    $count = 0;

    foreach ($numbers as $number) {
        $sum += $number;
        $count++;
    }

    if ($count > 0) {
        $average = $sum / $count;
        return $average;
    } else {
        return null;
    }
}

$average = calculate($numbers);

if ($average !== null) {
    echo "The average is: " . $average;
} else {
    echo "The array is empty.";
}
?>