<!-- 2. Chunk the array of N size without using php inbuilt function. -->

<?php 

$array = [1, 2, 3, 4, 5, 6, 7, 8, 9];
$size = 3;

function chunkArray($array, $size) {
    if(empty($array)) {
        return "Array is Empty.";
    }
    $chunk = [];
    $i = 0;
    $j = 0;
    foreach ($array as $item) { 
        if ($i == $size) {
            $j++;
            $i = 0;
        }

        if($i < $size) { 
            $chunk[$j][] = $item;
            $i++;
        }
    }
    return $chunk;
}

$newArray = chunkArray($array, $size);
print_r($newArray);
?>