<!-- 7. Write a PHP function that counts the number of vowels and consonants 
        in a given string without using regular expressions. -->

<?php

$vowelCount = 0;
$consonantCount = 0;

$str = "Hello world!";
echo $str."<br>";
$str2 = strtolower($str);

$length = strlen($str2);

for($i = 0; $i < $length; $i++) {
    if($str2[$i] == 'a' || $str2[$i] == 'e' || $str2[$i] == 'i' || $str2[$i] == 'o' || $str2[$i] == 'u') {
        $vowelCount++;
    }

    elseif($str2[$i] >= 'a' && $str2[$i] <= 'z') {  
        $consonantCount++;  
    }
}
echo "Number of vowels : ".$vowelCount."<br>";
echo "Number of consonants : ".$consonantCount;  
?> 