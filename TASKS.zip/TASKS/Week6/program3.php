<!-- 3. Find Maximum and Minimum Numbers. -->

<?php 

$array = [1, 10, 4, 5, 9, 2, 6, 5, 3, 5];

function maxNo($array) {
    $max = $array[0];
    for ($i = 1; $i < count($array); $i++)
        if ($max < $array[$i]) 
        {
            $max = $array[$i];
        }    
     return $max;      
 }

 function minNo($array)
 {
    $min = $array[0];
    for ($i = 1; $i < count($array); $i++)
        if ($min > $array[$i])
        {
            $min = $array[$i];
        }    
       return $min;      
 } 

echo "Maximum no: ".maxNo($array)."<br>";    
echo "Minimum no: ".minNo($array);    
?>