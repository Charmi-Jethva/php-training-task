<!-- 8. Create a PHP function that checks if a given 
        year is a leap year and displays the result. -->

<?php
$year = 2000;

if ($year % 4 == 0 && $year % 100 != 0 || $year % 400 == 0) {
   echo $year." is a leap year.";
} else {
   echo $year." is not a leap year.";
}
?>