<!-- 1. Write the script to Sort the numeric array without using php builtin functions. -->

<?php 
 
 $array = [3, 10, 4, 1, 5, 9, 2, 6, 5, 3, 5]; 
 
 for($i = 0; $i < count($array); $i++ ) { 
    for($j = 0; $j < count($array)-1; $j++) { 
        if($array[$j+1] < $array[$j]){ 
            $temp = $array[$j+1]; 
            $array[$j+1] = $array[$j]; 
            $array[$j] = $temp; 
            } 
        } 
    } 
print_r($array); 
?>