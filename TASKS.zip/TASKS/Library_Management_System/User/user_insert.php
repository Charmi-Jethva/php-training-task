<?php
require('../connect.php');
$name = $_POST['username'];
$email = $_POST['useremail'];
$gender = $_POST['usergender'];
$password = $_POST['userpassword'];

$stmt = $connection->prepare("INSERT INTO user_registration (name, email, gender,  password) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $email, $gender,  $password);

if ($stmt->execute()) {
    echo "Registration completed successfully!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$connection->close();
