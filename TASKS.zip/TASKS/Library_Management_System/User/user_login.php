<?php
require('../connect.php');

session_start();

$emailError = "";
$passwordError = "";
$loginError = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (empty($email)) {
        $emailError = "Email is required";
    } else {
        $email = trim($email);
        $email = htmlspecialchars($email);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailError = "Email should contain a valid format";
        }
    }

    if (empty($password)) {
        $passwordError = "Password is required";
    } else {
        $password = trim($password);
        $password = htmlspecialchars($password);

        if (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/", $password)) {
            $passwordError = "Password should meet the criteria";
        }
    }

    if (empty($emailError) && empty($passwordError)) {

        $stmt = $connection->prepare("SELECT * FROM user_registration WHERE email = ? AND password = ?");
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {

            $user = $result->fetch_assoc();
            $_SESSION['user_id'] = $user['user_id'];
            header("Location: user_dashboard.php");

            exit();
        } else {
            $loginError = "Invalid login credentials. Please try again.";
        }

        $stmt->close();
        $connection->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Login</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <h2>Login Form</h2>

        <div class="content">
            <label for="email">Email:</label>
            <input type="text" name="email">
            <span style="color: red;"><?php echo $emailError ?></span>
            <br><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password">
            <span style="color: red;"><?php echo $passwordError ?></span>
            <br><br>

            <span style="color: red;"><?php echo $loginError ?></span>
            <button type="submit" name="submit" id="submitBtn">Submit</button>
            <br><br>
        </div>
    </form>
</body>

</html>