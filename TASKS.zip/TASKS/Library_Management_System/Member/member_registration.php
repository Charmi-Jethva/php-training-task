<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignUp Form</title>
    <link rel="stylesheet" href="../style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>

<body>
    <form id="data" method="post">
        <h2>User SignUp Form</h2>

        <div class="content">
            <label for="name">Name:</label>
            <input type="text" id="name" name="username">
            <p class="error" id="nameError"></p>

            <label for="email">Email:</label>
            <input type="text" id="email" name="useremail">
            <p class="error" id="emailError"></p>

            <label for="gender">Gender:</label>
            <select id="gender" name="usergender">
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>
            <p class="error" id="genderError"></p>



            <label for="job_title">Job Title:</label>
            <input type="text" id="job_title" name="userjob_title">
            <p class="error" id="job_titleError"></p>

            <label for="password">Password:</label>
            <input type="password" id="password" name="userpassword">
            <p class="error" id="passwordError"></p>

            <label for="confirmPassword">Confirm Password:</label>
            <input type="password" id="confirmPassword">
            <p class="error" id="confirmPasswordError"></p>
            <br>
            <div>
                <button type="button" id="submitBtn">Submit</button>
            </div>
            <div id="form">
            </div>
        </div>
    </form>
    <script>
        $(document).ready(function() {
            $("#submitBtn").click(function() {

                var name = $("#name").val();
                var email = $("#email").val();
                var gender = $("#gender").val();
                var job_title = $("#job_title").val();
                var password = $("#password").val();
                var confirmPassword = $("#confirmPassword").val();

                $(".error").hide();

                // For Name
                var regex = /[A-Za-z]/;

                if (!name) {
                    $("#nameError").text("Name is required.").show();
                } else if (!regex.test(name)) {
                    $("#nameError").text("Name must entered in Alphabet").show();
                } else {
                    $("#nameError").hide();
                }

                // For Email
                var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;

                if (!email) {
                    $("#emailError").text("Email is required.").show();
                } else if (!regex.test(email)) {
                    $("#emailError").text("Invalid email format.").show();
                } else {
                    $("#emailError").hide();
                }



                // For Job Title
                var job_title = $("#job_title").val();

                if (!job_title) {
                    $("#job_titleError").text("Job Title is required.").show();
                } else {
                    $("#job_titleError").hide();
                }


                // For Password
                var regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{10,}$/;

                if (!password) {
                    $("#passwordError").text("password is required.").show();
                } else if (!regex.test(password)) {
                    $("#passwordError").text("Invalid password format.").show();
                } else {
                    $("#passwordError").hide();
                }

                // Confirm password

                if (confirmPassword != password) {
                    $("#confirmPasswordError").text("Passwords do not match.").show();
                } else {
                    $("#confirmPasswordError").hide();
                }

                if ($(".error:visible").length === 0) {
                    $.ajax({
                        type: "POST",
                        url: "staff_insert.php",
                        data: $("#data").serialize(),
                        success: function(response) {
                            $("#form").show();
                            $("#form").html("<p>Registration completed successfully!</p>");
                            $("#data")[0].reset();
                        }
                    });
                }
            });

        });
    </script>
</body>

</html>