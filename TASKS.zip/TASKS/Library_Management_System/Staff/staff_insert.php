<?php
require('../connect.php');
$name = $_POST['username'];
$email = $_POST['useremail'];
$gender = $_POST['usergender'];
$job_title = $_POST['userjob_title'];
$password = $_POST['userpassword'];

$stmt = $connection->prepare("INSERT INTO staff_registration (name, email, gender, job_title, password) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $name, $email, $gender, $job_title, $password);

if ($stmt->execute()) {
    echo "Registration completed successfully!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$connection->close();
