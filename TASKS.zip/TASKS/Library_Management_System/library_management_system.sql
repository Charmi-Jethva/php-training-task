-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 18, 2024 at 05:11 AM
-- Server version: 8.0.37-0ubuntu0.20.04.3
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admindetails`
--

CREATE TABLE `admindetails` (
  `id` int NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `moblie_no` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admindetails`
--

INSERT INTO `admindetails` (`id`, `username`, `email`, `password`, `moblie_no`, `created_at`) VALUES
(2, 'Hirva', 'hirva123@gmail.com', 'Hirva@123456', '9773090110', '2023-09-28 06:24:06'),
(3, 'Charmi', 'charmi@gmail.com', 'Charmi@12345', '987654321', '2023-09-28 06:36:21');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int NOT NULL,
  `book_name` varchar(40) NOT NULL,
  `category_id` int DEFAULT NULL,
  `author_id` int UNSIGNED DEFAULT NULL,
  `publisher_id` int DEFAULT NULL,
  `book_no` int NOT NULL,
  `book_price` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `book_name`, `category_id`, `author_id`, `publisher_id`, `book_no`, `book_price`, `created_at`, `updated_at`) VALUES
(2, 'data science', 3, 3, 1, 124, 250, '2023-09-25 09:08:51', '2023-09-22 05:16:25'),
(5, 'Doremon magazine', 2, 2, 1, 269, 1000, '2023-09-25 09:13:00', '0000-00-00 00:00:00'),
(6, 'software eng', 2, 1, 1, 12, 300, '2023-09-27 16:49:23', '0000-00-00 00:00:00'),
(7, 'Cricket', 6, 1, 4, 15, 350, '2023-09-28 06:53:09', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `book_author`
--

CREATE TABLE `book_author` (
  `id` int UNSIGNED NOT NULL,
  `author_name` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_author`
--

INSERT INTO `book_author` (`id`, `author_name`, `created_at`) VALUES
(1, 'M K Gupta', '2023-09-22 11:59:12'),
(2, 'Chetan Singhaniya', '2023-09-22 12:03:11'),
(3, 'Charmi Jethva', '2023-09-22 11:03:07'),
(5, 'Drashti', '2023-09-28 06:56:03');

-- --------------------------------------------------------

--
-- Table structure for table `book_borrows`
--

CREATE TABLE `book_borrows` (
  `id` int NOT NULL,
  `book_no` int NOT NULL,
  `book_name` varchar(20) NOT NULL,
  `book_author` varchar(20) NOT NULL,
  `member_id` int DEFAULT NULL,
  `issued_date` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'o - Not Issued, 1 - Issued',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_borrows`
--

INSERT INTO `book_borrows` (`id`, `book_no`, `book_name`, `book_author`, `member_id`, `issued_date`, `status`, `created_at`, `updated_at`) VALUES
(4, 24, 'data science', 'M k Gupta', 1, '2023-08-09', 1, '2023-09-27 05:42:18', '2023-09-27 05:42:18'),
(5, 24, 'Doremon magazine', 'M K Gupta', 1, '2323-09-27', 1, '2023-09-27 05:42:18', '2023-09-27 05:42:18'),
(6, 24, 'Doremon magazine', 'M K Gupta', 1, '2323-09-27', 1, '2023-09-27 05:42:18', '2023-09-27 05:42:18'),
(7, 24, 'Doremon magazine', 'M K Gupta', 1, '2323-09-27', 1, '2023-09-27 05:42:18', '2023-09-27 05:42:18'),
(8, 12, 'data science', 'Charmi Jethva', 1, '2323-09-27', 1, '2023-09-27 05:42:18', '2023-09-27 05:42:18');

-- --------------------------------------------------------

--
-- Table structure for table `book_category`
--

CREATE TABLE `book_category` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_category`
--

INSERT INTO `book_category` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'novel', '2023-09-22 05:24:42', '2023-09-22 05:24:42'),
(2, 'computer science ', '2023-09-22 05:24:42', '2023-09-22 05:24:42'),
(3, 'Story', '2023-09-22 05:24:42', '2023-09-22 05:24:42'),
(4, 'Action', '2023-09-22 10:03:27', '0000-00-00 00:00:00'),
(5, 'Adventure', '2023-09-22 10:25:36', '0000-00-00 00:00:00'),
(6, 'Sports', '2023-09-22 11:24:16', '0000-00-00 00:00:00'),
(10, 'Information Technology', '2023-09-28 06:54:21', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `book_hold`
--

CREATE TABLE `book_hold` (
  `id` int NOT NULL,
  `borrowed_id` int DEFAULT NULL,
  `last_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_hold`
--

INSERT INTO `book_hold` (`id`, `borrowed_id`, `last_date`, `created_at`, `updated_at`) VALUES
(2, 4, '2023-09-11', '2023-09-27 07:43:20', '2023-09-27 07:43:20');

-- --------------------------------------------------------

--
-- Table structure for table `book_purchase`
--

CREATE TABLE `book_purchase` (
  `id` int UNSIGNED NOT NULL,
  `book_id` int DEFAULT NULL,
  `member_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `purchase_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_purchase`
--

INSERT INTO `book_purchase` (`id`, `book_id`, `member_id`, `user_id`, `purchase_date`, `created_at`, `updated_at`) VALUES
(1, 5, 2, NULL, '2023-09-03', '2023-09-26 07:16:15', '2023-09-26 07:16:15'),
(2, 5, 1, NULL, '2023-08-13', '2023-09-26 07:16:15', '2023-09-26 07:16:15');

-- --------------------------------------------------------

--
-- Table structure for table `book_requested`
--

CREATE TABLE `book_requested` (
  `id` int NOT NULL,
  `member_id` int DEFAULT NULL,
  `book_id` int DEFAULT NULL,
  `requested_date` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 - Not Available, 1 - Available',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_requested`
--

INSERT INTO `book_requested` (`id`, `member_id`, `book_id`, `requested_date`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 5, '2023-09-05', 1, '2023-09-25 11:01:16', '2023-09-25 11:01:16'),
(2, 2, 2, '2023-08-14', 1, '2023-09-25 11:01:16', '2023-09-25 11:01:16');

-- --------------------------------------------------------

--
-- Table structure for table `book_review`
--

CREATE TABLE `book_review` (
  `id` int NOT NULL,
  `member_id` int NOT NULL,
  `reviewText` varchar(40) NOT NULL,
  `rating` int NOT NULL,
  `review_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_review`
--

INSERT INTO `book_review` (`id`, `member_id`, `reviewText`, `rating`, `review_date`, `created_at`) VALUES
(1, 2, 'This book is nice', 4, '2023-08-01', '2023-09-27 16:37:21');

-- --------------------------------------------------------

--
-- Table structure for table `event_registration`
--

CREATE TABLE `event_registration` (
  `id` int NOT NULL,
  `event_id` int NOT NULL,
  `member_id` int NOT NULL,
  `registration_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_registration`
--

INSERT INTO `event_registration` (`id`, `event_id`, `member_id`, `registration_date`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2023-09-13', '2023-09-23 14:58:26', '2023-09-23 14:58:26'),
(2, 1, 2, '2023-09-09', '2023-09-28 07:55:32', '2023-09-28 07:55:32'),
(3, 2, 1, '2023-09-02', '2023-09-28 08:03:49', '2023-09-28 08:03:49');

-- --------------------------------------------------------

--
-- Table structure for table `library_branches`
--

CREATE TABLE `library_branches` (
  `id` int NOT NULL,
  `branch_name` varchar(20) NOT NULL,
  `address` varchar(40) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `library_branches`
--

INSERT INTO `library_branches` (`id`, `branch_name`, `address`, `created`) VALUES
(1, 'trikon baug', 'trikon baug main road', '2023-09-20 11:05:16'),
(2, 'kalavad', 'kalavad road', '2023-09-20 11:05:16');

-- --------------------------------------------------------

--
-- Table structure for table `library_card`
--

CREATE TABLE `library_card` (
  `id` int NOT NULL,
  `member_id` int DEFAULT NULL,
  `issued_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `library_card`
--

INSERT INTO `library_card` (`id`, `member_id`, `issued_date`, `expiry_date`, `created_at`, `updated_at`) VALUES
(1, 1, '2023-08-09', '2024-08-08', '2023-09-26 07:47:18', '2023-09-26 07:47:18'),
(2, 2, '2023-09-01', '2024-08-31', '2023-09-26 07:47:18', '2023-09-26 07:47:18');

-- --------------------------------------------------------

--
-- Table structure for table `library_events`
--

CREATE TABLE `library_events` (
  `id` int NOT NULL,
  `branch_id` int NOT NULL,
  `event_name` varchar(20) NOT NULL,
  `event_date` date NOT NULL,
  `description` varchar(40) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `library_events`
--

INSERT INTO `library_events` (`id`, `branch_id`, `event_name`, `event_date`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 'book fair', '2023-09-30', 'Book Fair for members.', '2023-09-23 14:35:12', '2023-09-23 14:35:12'),
(2, 2, 'comedy show ', '2023-09-27', 'comedy show ', '2023-09-23 14:35:12', '2023-09-23 14:35:12');

-- --------------------------------------------------------

--
-- Table structure for table `library_review`
--

CREATE TABLE `library_review` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `member_id` int DEFAULT NULL,
  `reviewText` varchar(60) NOT NULL,
  `rating` enum('1','2','3','4','5') NOT NULL,
  `review_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `library_review`
--

INSERT INTO `library_review` (`id`, `user_id`, `member_id`, `reviewText`, `rating`, `review_date`, `created_at`) VALUES
(1, 1, NULL, 'LIbrary is too nice', '5', '2023-09-07', '2023-09-25 06:45:17'),
(2, NULL, 1, 'Some issue need to solve ', '2', '2023-09-13', '2023-09-25 06:45:17');

-- --------------------------------------------------------

--
-- Table structure for table `member_registration`
--

CREATE TABLE `member_registration` (
  `id` int NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `gender` enum('Male','Female','Others','') NOT NULL,
  `password` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member_registration`
--

INSERT INTO `member_registration` (`id`, `username`, `email`, `gender`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Manav Bhavsar', 'manav@gmail.com', 'Male', 'Manav@1234', '2023-09-22 05:08:51', '0000-00-00 00:00:00'),
(2, 'Dhanvi', 'dhanvi@gmail.com', 'Male', 'Dhanvi@1234', '2023-09-28 07:17:36', '2023-09-28 07:17:36');

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

CREATE TABLE `publisher` (
  `id` int NOT NULL,
  `publisher_name` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`id`, `publisher_name`, `created_at`, `updated_at`) VALUES
(1, 'Aryan Jethva', '2023-09-22 12:21:19', '2023-09-22 11:30:08'),
(4, 'Meera Jethva', '2023-09-22 12:21:19', '2023-09-22 11:30:08'),
(6, 'M k gandhi', '2023-09-28 06:55:38', '2023-09-28 06:54:35');

-- --------------------------------------------------------

--
-- Table structure for table `staff_registration`
--

CREATE TABLE `staff_registration` (
  `id` int NOT NULL,
  `branch_id` int NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `gender` enum('Male','Female','Other','') NOT NULL,
  `job_title` varchar(40) NOT NULL,
  `password` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_registration`
--

INSERT INTO `staff_registration` (`id`, `branch_id`, `username`, `email`, `gender`, `job_title`, `password`, `created_at`, `updated_at`) VALUES
(1, 2, 'Abhisha', 'abhisha123@gmail.com', 'Female', 'Genral', 'Abhisha@12345', '2023-09-23 15:33:31', '2023-09-23 15:33:31'),
(2, 2, 'Mishri', 'mishri@gmail.com', 'Female', 'Assistant', 'mishri@1234', '2023-09-28 07:01:17', '2023-09-28 07:01:17');

-- --------------------------------------------------------

--
-- Table structure for table `user_registration`
--

CREATE TABLE `user_registration` (
  `id` int NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(20) NOT NULL,
  `gender` enum('Male','Female','Others','') NOT NULL,
  `password` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_registration`
--

INSERT INTO `user_registration` (`id`, `name`, `email`, `gender`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Abhisha', 'abhisha@gmail.com', 'Male', 'abhisha@1234', '2023-09-21 05:37:52', '2023-09-21 05:37:52'),
(2, 'ishita', 'ishita@gmail.com', 'Female', 'Ishita@1234', '2023-09-21 05:55:39', '2023-09-21 05:55:39'),
(3, 'isha', 'isha@gmail.com', 'Female', 'Ishita@1234', '2023-09-21 10:16:41', '2023-09-21 10:16:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admindetails`
--
ALTER TABLE `admindetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`author_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `publisher_id` (`publisher_id`);

--
-- Indexes for table `book_author`
--
ALTER TABLE `book_author`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_borrows`
--
ALTER TABLE `book_borrows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`book_author`);

--
-- Indexes for table `book_category`
--
ALTER TABLE `book_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_hold`
--
ALTER TABLE `book_hold`
  ADD PRIMARY KEY (`id`),
  ADD KEY `borrowed_id` (`borrowed_id`);

--
-- Indexes for table `book_purchase`
--
ALTER TABLE `book_purchase`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `book_requested`
--
ALTER TABLE `book_requested`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `book_review`
--
ALTER TABLE `book_review`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `event_registration`
--
ALTER TABLE `event_registration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event_id` (`event_id`),
  ADD KEY `event_registration_ibfk_2` (`member_id`);

--
-- Indexes for table `library_branches`
--
ALTER TABLE `library_branches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `library_card`
--
ALTER TABLE `library_card`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `library_events`
--
ALTER TABLE `library_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `library_review`
--
ALTER TABLE `library_review`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `member_registration`
--
ALTER TABLE `member_registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `publisher`
--
ALTER TABLE `publisher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_registration`
--
ALTER TABLE `staff_registration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_registration_ibfk_1` (`branch_id`);

--
-- Indexes for table `user_registration`
--
ALTER TABLE `user_registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admindetails`
--
ALTER TABLE `admindetails`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `book_author`
--
ALTER TABLE `book_author`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `book_borrows`
--
ALTER TABLE `book_borrows`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `book_category`
--
ALTER TABLE `book_category`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `book_hold`
--
ALTER TABLE `book_hold`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `book_purchase`
--
ALTER TABLE `book_purchase`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `book_requested`
--
ALTER TABLE `book_requested`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `book_review`
--
ALTER TABLE `book_review`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `event_registration`
--
ALTER TABLE `event_registration`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `library_branches`
--
ALTER TABLE `library_branches`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `library_card`
--
ALTER TABLE `library_card`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `library_events`
--
ALTER TABLE `library_events`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `library_review`
--
ALTER TABLE `library_review`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `member_registration`
--
ALTER TABLE `member_registration`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `publisher`
--
ALTER TABLE `publisher`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `staff_registration`
--
ALTER TABLE `staff_registration`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_registration`
--
ALTER TABLE `user_registration`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `books_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `book_author` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `books_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `book_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `books_ibfk_3` FOREIGN KEY (`publisher_id`) REFERENCES `publisher` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `book_hold`
--
ALTER TABLE `book_hold`
  ADD CONSTRAINT `book_hold_ibfk_1` FOREIGN KEY (`borrowed_id`) REFERENCES `book_borrows` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `book_purchase`
--
ALTER TABLE `book_purchase`
  ADD CONSTRAINT `book_purchase_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member_registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `book_purchase_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user_registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `book_purchase_ibfk_3` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `book_requested`
--
ALTER TABLE `book_requested`
  ADD CONSTRAINT `book_requested_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member_registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `book_requested_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `book_review`
--
ALTER TABLE `book_review`
  ADD CONSTRAINT `book_review_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member_registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `event_registration`
--
ALTER TABLE `event_registration`
  ADD CONSTRAINT `event_registration_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `library_events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `event_registration_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `member_registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `library_card`
--
ALTER TABLE `library_card`
  ADD CONSTRAINT `library_card_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member_registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `library_events`
--
ALTER TABLE `library_events`
  ADD CONSTRAINT `library_events_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `library_branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `library_review`
--
ALTER TABLE `library_review`
  ADD CONSTRAINT `library_review_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member_registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `library_review_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user_registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `staff_registration`
--
ALTER TABLE `staff_registration`
  ADD CONSTRAINT `staff_registration_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `library_branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
