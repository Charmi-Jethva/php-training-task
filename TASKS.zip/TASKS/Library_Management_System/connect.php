<?php

$connection = mysqli_connect('localhost', 'root', '', 'library_management_system');

if ($connection->connect_error) {
    die('Connection Failed: ' . $connection->connect_error);
}
