<?php
require('../connect.php');
session_start();

$usernameError = "";
$passwordError = "";
$loginError = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["submit"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];

        if (empty($username)) {
            $usernameError = "Username is required";
        } else {
            if (!preg_match("/^[a-zA-Z]+$/", $username)) {
                $usernameError = "Username should only contain letters";
            }
        }

        if (empty($password)) {
            $passwordError = "Password is required";
        } else {
            $password = trim($password);
            $password = htmlspecialchars($password);

            if (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/", $password)) {
                $passwordError = "Password should meet the criteria";
            }
        }

        if (empty($usernameError) && empty($passwordError)) {
            $stmt = $connection->prepare("SELECT * FROM admindetails WHERE username = ? AND password = ?");
            $stmt->bind_param("ss", $username, $password);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                echo "zdcfvgbnm";
                $_SESSION["username"] = $username;
                header("Location: admin_dashboard.php");
                exit();
            } else {
                $loginError = "Invalid login credentials. Please try again.";
            }

            $stmt->close();
            $connection->close();
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <div class="center-heading">
        <h2 class="library-heading">Admin Login</h2>
    </div>
    <form id="data" method="post">
        <div class="container">
            <br>
            <div class="content">
                <label for="username">Username :</label>
                <input type="text" name="username">
                <span style="color: red;"><?php echo $usernameError ?></span>
            </div>
            <br>

            <label for="password">Password :</label>
            <input type="password" id="password" name="password">
            <span style="color: red;"><?php echo $passwordError ?></span>

            <br><br>

            <span style="color: red;"><?php echo $loginError ?></span>
            <button type="submit" name="submit" id="submitBtn">Submit</button>
            <br><br>
        </div>
    </form>
</body>

</html>