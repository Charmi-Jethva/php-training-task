<!-- create a loop that generates random numbers until a number divisible by both 3 and 5 is generated. -->

<?php

do 
{
    $n = rand(1, 100);
} 
while ($n % 3 != 0 || $n % 5 != 0);

echo "It can be divided by both : $n";

?>
