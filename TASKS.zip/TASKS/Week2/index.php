
<?php

$attempts = 0;
$n = rand(1, 100);

do {
    
    $num = (readline("Enter the number:"));
    if ($num < $n) {
        echo "Number is too lower than $n \n";
    } elseif ($num > $n) {
        echo "Number is too higher than $n \n";
    } else {
        if ($attempts == 1) {
            echo "Congratulations! You guessed the number in $attempts attempt.";
        } elseif ($attempts == 2 or 3) {
            echo "Great job! You guessed the number in $attempts attempts.";
        } else {
            "You guessed the number in  $attempts attempts.";
        }
    }
    $attempts++;
} while ($num != $n);




?>