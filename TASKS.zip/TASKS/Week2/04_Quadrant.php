<!--"Write a PHP program that takes the coordinates (x, y) of a point as input and determines in which quadrant that point lies. The quadrants are defined as follows:

Quadrant I: Both x and y are positive.
Quadrant II: x is negative and y is positive.
Quadrant III: Both x and y are negative.
Quadrant IV: x is positive and y is negative.
Your program should output the quadrant number or indicate if the point lies on an axis (x-axis or y-axis), or at the origin (0, 0)."-->

<?php
$x = 1;
$y = 0;

if($x>0 && $x>0)
{
    echo "$a and $y both are positive"; 
}
elseif($x<0 && $y<0)
{
    echo "$a and $y both are negetive";
}
elseif($x>0 && $y<0)
{
    echo "$x is positive <br> $y is negative";
}
elseif($x<0 && $y>0)
{
    echo "$x is negative <br> $y is positive";
}
elseif($x==0 && $y==0)
{
    echo  "The point is at the origin (0, 0)";
}
elseif($x==0)
{
    echo "The point lies on the y-axis";
}
elseif ($y==0) 
{
    echo "The point lies on the x-axis";
}
else
{
    echo "$x and $y";   
}
?>