<!-- "Let's say you have an array of numbers, and you want to calculate the sum of the squares of all 
      the even numbers in the array, but only up to a certain limit. 
      You want to use both a for loop and a foreach loop to achieve this. Here's how you could do it

     $numbers = [1, 20, 4, 60, 6, 3, 8, 10, 12, 14, 16];"-->

<?php
$numbers = [1,2,3,4,5,6,7,8,9,10];

function evenNumbers($arr) 
{
    $result = array();
    foreach ($arr as $element)
     {
        if ($element % 2 == 0) 
        {
            $result[] = $element;
        }
    }
    return $result;
}

$r = evenNumbers($numbers);
print_r($r);

foreach($r as $arry){
  echo $arry . " of square is => " . $arry * $arry;
  echo "<br>";
}
    
?>