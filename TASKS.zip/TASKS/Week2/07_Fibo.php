<!--write a php script to print Fibonacci sequence and then displays the sequence upto $n and $n should be user input-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fibonacci Series</title>
</head>
<body>
<h3>Fibonacci Series</h3>
    <form method="post">
    Enter number :
    <input type="text" name="number">
    <br><br>
    <input type="submit" name="action">
</body>

<?php

if(isset($_POST['action'])) {
$n = $_POST['number'];

$num = 0;
$n1 = 1;
echo "<br><br> Fibo series is: \n"; 
echo $num. ' ' .$n1. ' ';

while($num < $n)
{
    $n3 = $num + $n1;
    echo $n3. ' ';
    $num = $n1;
    $n1 = $n3;
}
}
?>
</html>