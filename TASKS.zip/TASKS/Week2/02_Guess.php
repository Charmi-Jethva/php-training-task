<!--"Write a PHP program that generates a random number between 1 and 100 (inclusive) and asks the user to guess the number. The program should provide hints whether the guessed number is too high or too low, and allow the user to continue guessing until they correctly guess the number. Once the correct number is guessed, the program should display the number of attempts it took the user to guess correctly, along with a message based on the number of attempts:

If it took the user 1 attempt, display: ""Congratulations! You guessed the number in 1 attempt.""
If it took the user 2 or 3 attempts, display: ""Great job! You guessed the number in 2 (or 3) attempts.""
If it took the user more than 3 attempts, display: ""You guessed the number in X attempts."""-->

<?php
  $n = rand(1, 10);
  $attempts = 0;

  echo "Welcome..!!!!\n";
  echo "Selected no between 1 to 100";

  while(true) {
    $guess = readline("Enter your no: ");

    if(!is_numeric($guess)) {
        echo "Enter valid number: \n";
    }
       $attempts++;

    if($guess < $n)
    {
        echo "This number is too low. \n";
    }
    elseif($guess > $n)
    {
        echo "This number is too high. \n";
    }
    else {
        if($attempts === 1) {
            echo "Congrates you guessed no in 1st attempt. \n ";
        }
        elseif($attempts >= 2 && $attempts <= 3) {
            echo "wow you guessed no in {$attempts} attempts. \n";
        }
        else {
            echo "you guessed no in {$attempts} attempts. \n";
        }
        break;
    }
  }
?>
