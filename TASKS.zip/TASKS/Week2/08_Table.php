<!-- write a script in PHP with an HTML and CSS design to print a multiplication table depending on user input. -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table</title>
</head>
<body>
    <h3>Table</h3>
    <form method="post">
    Enter number :
    <input type="text" name="num">
    <br><br>
    <input type="submit" name="submit">
    </form>
</body>

<?php
  if($_POST) {
    $number = $_POST['num'];
    for($i = 1; $i <= 10; $i++)
{
    echo ("<p>".$number. " *".$i ." = ". $number * $i."<br></p>");
}
  }
?>

</html>