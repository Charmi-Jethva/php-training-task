<!-- write a php script for remove even number form given array $input = [ 1 , 2, 3,22,45,23,112 ] or take any array you want and return remaining value -->

<?php
$input = [1, 2, 3, 22, 45, 23, 112];

function removeEvenNumbers($arr) 
{
    $result = array();
    foreach ($arr as $element)
     {
        if ($element % 2 !== 0) 
        {
            $result[] = $element;
        }
    }
    return $result;
}

$r = removeEvenNumbers($input);
print_r($r);
?>
