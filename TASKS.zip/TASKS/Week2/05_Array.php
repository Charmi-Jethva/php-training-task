<!--write a php script, get user input day name and print day in "GUJARATI" like 
    user input "monday" then output should be "સોમવાર"-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array</title>
</head>
<body>
    <form method="post">
    Enter a day :
    <input type="text" name="day">
    <br><br>
    <input type="submit" name="submit">
    <br><br>
</body>
<?php
  
  if($_POST) {
    $day = $_POST['day'];
  if($day == 'Sunday')
  {
    echo "રવિવાર";
  }
  elseif($day == 'Monday')
  {
    echo "સોમવાર";
  }
  elseif($day == 'Tuesday')
  {
    echo "મંગળવાર";
  }
  elseif($day == 'Wednesday')
  {
    echo "બુધવાર";
  }
  elseif($day == 'Thursday')
  {
    echo "ગુરુવાર";
  }
  elseif($day == 'Friday')
  {
    echo "શુક્રવાર";
  }
  elseif($day == 'Saturday')
  {
    echo "શનિવાર";
  }
  else {
    echo "આ વાર ગુજરાતી મા ના હોય";
  }
} 
?>

</html>

<?php
// $charmi = [
//   'sunday'     =>  'રવિવાર',
//   'monday'     =>  'સોમવાર',
//   'tuesday'    =>  'મંગળવાર',
//   'wedenesday' =>  'બુધવાર',
//   'thursday'   =>  'ગુરુવાર',
//   'friday'     =>  'શુક્રવાર',
//   'saturday'   =>  'શનિવાર'
// ];

// if($_POST) {
//   $userinput = $_POST['day'];
// if(array_key_exists($userinput, $charmi))
// {
//    $day = $charmi[$userinput];
//    echo "The name of gujrati day  ".$day;
// } 
// else 
// {
//   echo "Invalid day enters";
// }
// } 
?>

