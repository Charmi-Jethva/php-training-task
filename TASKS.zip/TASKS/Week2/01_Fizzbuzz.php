<!-- "$number = rand(1, 100); // Generate a random number between 1 and 100

  Your task is to write an if-else statement that does the following:
 - If the number is divisible by 3, print ""Fizz""
 - If the number is divisible by 5, print ""Buzz""
 - If the number is divisible by both 3 and 5, print ""FizzBuzz""
 - If none of the above conditions are met, print the number itself" -->

 <?php
 $n = rand(1,100);

 if($n % 3 === 0 && $n % 5 === 0)
 {
    echo "FizzBuzz";
 }
 elseif($n % 3 === 0)
 {
    echo "Fizz"; 
 }
 elseif($n % 5 === 0)
 {
    echo "Buzz";
 }
 else
 {
    echo $n;
 }
 ?>