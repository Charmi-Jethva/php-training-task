<!-- simulate a game where the player rolls a dice until they roll a 6, 
and we'll keep track of the number of rolls it takes to get a 6. -->

<?php

$rolls = 0;

do 
{
    $roll = rand(1, 6);
    $rolls++;
} 
while ($roll != 6);

echo "It took {$rolls} rolls to get a 6.";

?>
