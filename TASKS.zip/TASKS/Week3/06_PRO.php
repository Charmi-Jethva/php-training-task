<!-- Develop a script that takes a paragraph as input and outputs a list of unique words in the paragraph along with their frequencies. -->

<?php
$paragraph = "This is a test. This is only a test. Testing the script";

function countWords($paragraph) {
    $words = explode(" ", $paragraph); 
    $wordCount = [];
    
    foreach ($words as $word) {
        $word = strtolower($word); 
        if (isset($wordCount[$word])) {
            $wordCount[$word]++;
        } else {
            $wordCount[$word] = 1;
        }
    }
    
    return $wordCount;
}

$wordfrequencies = countWords($paragraph);


echo "Frequencies of the given string: ";
echo "<br>";
foreach ($wordfrequencies as $word => $frequency) {
    echo $word . ": " . $frequency . "\n";
}

?>