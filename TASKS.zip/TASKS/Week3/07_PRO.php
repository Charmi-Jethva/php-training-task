<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2nd</title>
</head>
<body>
    <form method="post">
    Enter string :
    <input type="text" name="string">
    <br><br>
    <input type="submit" name="submit">
    <br><br>
</body>

<?php
if($_POST) {
    $str = $_POST['string'];

function acronym($str) {
    $input = explode(" ", $str); 
    $acronym = "";
    
    foreach ($input as $input) {
        $acronym .= strtoupper(substr($input, 0, 1)); 
    }
    
    return $acronym;
}

$output = acronym($str);
echo "Output: $output";

}
?>

</html>