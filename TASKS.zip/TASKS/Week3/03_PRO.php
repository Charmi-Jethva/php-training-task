<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3rd</title>
</head>
<body>
    <form method="post">
    Enter string :
    <input type="text" name="string">
    <br><br>
    <input type="submit" name="submit">
    <br><br>
</body>

<?php
if($_POST) {
    $str = $_POST['string'];

function countRepeatString($str) {
    $newstr = "";
    $length = strlen($str);
    $count = 1;
    
    for ($i = 0; $i < $length; $i++) {
        if ($i + 1 < $length && $str[$i] == $str[$i + 1]) {
            $count++;
        } else {
            $newstr .= $str[$i];
            if ($count > 1) {
                $newstr .= $count;
            }
            $count = 1;
        }
    }
    
    return $newstr;
}

$newstrString = countRepeatString($str);
echo "newstr String: $newstrString";

}
?>

</html>