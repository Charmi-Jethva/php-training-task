<!-- Write a script that removes all HTML and PHP tags from a string using strip_tags(). -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5th</title>
</head>
<body>
    <form method="post">
    Enter string :
    <input type="text" name="string">
    <br><br>
    <input type="submit" name="submit">
    <br><br>
</body>

<?php 
if($_POST) {
    $str = $_POST['string'];
    echo strip_tags($str);
}
?>

</html>