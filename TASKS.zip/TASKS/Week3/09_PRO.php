<?php 

    $input = "Hello there. This is an example paragraph. It contains multiple sentences. ";
    $words = explode( ". ", $input); 
    
   
    foreach($words as $word)
    {
       $result[] = implode(" ", array_reverse(explode(" ",$word)));
       
    }
    echo "<pre>";
    print_r (implode(".", $result));
   

    
?>