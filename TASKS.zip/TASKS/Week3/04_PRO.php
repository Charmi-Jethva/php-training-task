<!-- Write a script that replaces a specific word in a string with another word and after that also extracts and print a substring from a given replacement word. -->

<?php
$str = "I am Software Developer";
$result = str_replace("Developer","Engineer",$str);
echo $result."<br>";

$extract = substr($result,14);
echo $extract;
?>