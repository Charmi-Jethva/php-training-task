<?php

$links = "https://www.example.com/page?&name=john&age=25&location=city";
parse_str($links,$result);

echo "Name: ".$result['name']."<br>";
echo "Age: ".$result['age']."<br>";
echo "Location: ".$result['location'];
?>  
