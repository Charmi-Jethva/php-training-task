<!-- write a php script that calculates  and display the length of a string and also print that string into lower and upper case. trim the string and print the count of words of that string -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1st</title>
</head>
<body>
    <form method="post">
    Enter string :
    <input type="text" name="string">
    <br><br>
    <input type="submit" name="submit">
    <br><br>
</body>

<?php 
if($_POST) {
    $str = $_POST['string'];

$result = strlen($str);
echo "The length of string is: ".$result."<br>";

$lowercase = strtolower($str);
echo "The string in lower case: ".$lowercase."<br>";

$uppercase = strtoupper($str);
echo "The string in upper case: ".$uppercase."<br>";

$trimcase = trim($str, "Hello");
echo "The string after trim: ".$trimcase."<br>";

$rtrimcase = rtrim($str, "Hello");
echo "The string after rtrim: ".$rtrimcase."<br>";

$ltrimcase = ltrim($str, "Hello");
echo "The string after ltrim: ".$ltrimcase."<br>";

$wordcount = str_word_count($str);
echo "Total number of words is: ".$wordcount."<br>";
}
?>

</html>
