<!-- Write a script that takes a sentence as input and converts it to title case, where the first letter of each word is capitalized. However, certain small words like "and," "the," "of," etc., should remain lowercase unless they appear at the beginning of the sentence. -->

<?php 
function titleCase($sentence)
{
    $excludewords =  array('and', 'the', 'of', 'in', 'on', 'at', 'for', 'to', 'with');

    $words = explode(" ", strtolower($sentence));

    $words[0] = ucfirst($words[0]);

    for ($i = 1; $i < count($words); $i++) {
       
        if (!in_array($words[$i], $excludewords)) {
            $words[$i] = ucfirst($words[$i]);
           
        }
    }
    $titleCaseSentence = implode(" ", $words);
        
    return  $titleCaseSentence;
    
}  

$inputSentence = "the quick brown fox jumps over the lazy dog";
$titleCaseResult = titleCase($inputSentence);
echo $titleCaseResult;


?>

